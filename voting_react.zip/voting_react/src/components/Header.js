import headerTop from "../Assets/header-top.jpg";
import { makeStyles } from "@material-ui/core/styles";
import React, { useRef } from "react";

const useStyles = makeStyles((theme) => ({
  logoContainer: {
    textAlign: "center",
    
  },
  header: {
    width: '100%'
  },
  triangle: {
    marginTop: "0px",
    borderLeft: "49vw solid transparent",
    borderRight: "49vw solid transparent",
    borderTop: "50px solid #1486e3",
    margin: "0px auto",
  },
}));
const Header = () => {
  const classes = useStyles();
  const headerImageRef = useRef(null);

  return (
    <>
      <div className={classes.logoContainer}>
      
        <img className={classes.header} src={headerTop} alt="header" ref={headerImageRef}/>
        { headerImageRef?.current && 
          <div style={{position: 'absolute', 
                    top: headerImageRef.current.clientHeight, 
                    background: 'orange', 
                    width: '100%', 
                    height: `calc(100%  - ${headerImageRef.current.clientHeight}px)`,
                    }}>
            {headerImageRef.current.clientHeight}
        </div>
        }
          
      </div>
      
    </>
  );
};
export default Header;
