import React, { useRef } from "react";
import '../App.css';
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { ArrowForward, ArrowBack } from "@material-ui/icons";
import data from '../Assets/data.json';

const useStyles = makeStyles((theme) => {
  const firstColumnColor = "#4659e5";
  const topRowColor = "#DBE0FF";
  const darkBlue = "#2b39a4";
  const mainFontFamily = "Poppins";

  return {
    root: {
      //margin: "0px 40px 40px 40px",
      margin: "0px auto",
      width: "94vw",
      position: "relative",
    },
    container: {
      //height: "70vh",
      //overflowY: "scroll",
      overflowX: "hidden",
      //position: "relative",
      borderLeft: "solid 1px #eaeaea",
      borderRight: "solid 1px #eaeaea",
      borderBottom: "solid 1px #eaeaea",
      borderTop: "none",
      scrollBehavior: "smooth",
    },
    table: {
      borderCollapse: "separate",
      "&>thead>tr>th:first-child  ": {
        backgroundColor: firstColumnColor,
        position: "sticky",
        left: 0,
        top: 0,
        zIndex: 15,
        color: "white",
        fontFamily: mainFontFamily,
        fontWeight: "600",
        textAlign: "center",
        width: "250px",
        maxWidth: "250px",
        minWidth: "250px",
        borderLeft: "none !important",
        padding: "16px",
      },
      "&>tbody>tr>td:first-child": {
        backgroundColor: firstColumnColor,
        position: "sticky",
        left: 0,
        color: "white",
        fontFamily: mainFontFamily,
        fontWeight: "600",
        textAlign: "center",
        width: "282px",
        maxWidth: "282px",
        minWidth: "282px",
        //padding: "16px",
      },
      "&>thead>tr>th": {
        backgroundColor: topRowColor,
        color: "black",
        fontWeight: "600",
        position: "sticky",
        top: 0,
        minWidth: "300px",
        fontFamily: mainFontFamily,
        height: "87px",
        borderTop: "none",
        borderLeft: "none",
        borderRight: "solid 1px #eaeaea",
        zIndex: 10,
        //padding: "16px",
      },
      "&>tbody>tr>td": {
        borderTop: "none",
        borderLeft: "none",
        borderBottom: "solid 1px #808080",
        width: "432px",
        maxWidth: "432px",
        minWidth: "432px",
        //padding: "16px",
      },
      "&>tbody>tr:nth-child(2n)": {
        backgroundColor: "#f5f5f5",
      },
      "& a": {
        textDecoration: "none",
        color: firstColumnColor,
        fontFamily: mainFontFamily,
        fontWeight: "600",
      },
    },
    buttonDiv: {
      position: "absolute",
      zIndex: 100,
      //width: "calc(100vw - 80px)",
      width: "94vw",
      top: "0px",
      left: "0px",
    },
    buttonLeft: {
      position: "absolute",
      left: "232px",
      width: "50px",
      top: "0px",
      height: "86px",
      backgroundColor: darkBlue,
      fontFamily: mainFontFamily,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    buttonRight: {
      position: "absolute",
      right: "0px",
      width: "50px",
      top: "0px",
      height: "86px",
      backgroundColor: darkBlue,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    stickyRow: {
      height: "55px",
      width: "300px",
      position: "sticky", //paddingLeft: "500px",

      left: "calc(50vw - 150px)",
      fontSize: "36px",
      color: "white",
      zIndex: 5,
      textAlign: "left",
    },
    whiteIcon: {
      color: theme.palette.common.white,
    },
    alignTop: {
      verticalAlign: "top !important",
    },
    topRow: {
      position: "sticky",
      top: 0,
      left: 0,
      display: "flex",
      //width: "100%",
      //height: "55px",
      margin: "0px auto",
      width: "94vw",
      overflowX: "hidden",
      borderLeft: "solid 1px #eaeaea",
      borderRight: "solid 1px #eaeaea",
      borderTop: "solid 1px #eaeaea",
      borderBottom: "none",
      marginTop: "40px",
      zIndex: "200",
      scrollBehavior: "smooth",
    },
    first: {
      width: "282px",
      minWidth: "282px",
      maxWidth: "282px",
      backgroundColor: firstColumnColor,
      padding: "16px",
      height: "87px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "16px",
      fontWeight: "600",
      fontFamily: mainFontFamily,
      borderRight: "solid 1px #eaeaea",
      borderBottom: "solid 1px #9a9a9a",
      color: "white",
      position: "sticky",
      top: "0px",
      left: "0px",
    },
    rest: {
      width: "432px",
      minWidth: "432px",
      maxWidth: "432px",
      backgroundColor: topRowColor,
      fontFamily: mainFontFamily,

      padding: "16px",
      height: "87px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "16px",
      fontWeight: "600",
      borderRight: "solid 1px #9a9a9a",
      borderBottom: "solid 1px #9a9a9a"
    },
  };
});
const DataCell = withStyles((theme) => ({
  head: {
    backgroundColor: '#1486e3',
    width: "400px",
    color: theme.palette.common.white,
    borderRight: "solid 1px #e2e2e2",
    borderBottom: "solid 1px #e2e2e2",
    textAlign: "center",
    fontSize: "16px",
  },
  body: {

    fontSize: 14,
    border: "solid 1px #e2e2e2",
    textAlign: "center",
    borderRight: "solid 1px #e2e2e2",
    borderBottom: "solid 1px #e2e2e2",
    padding: 4,
    "& p": {
      margin: "6px 0",
    },
  },
}))(TableCell);

const DataTable = () => {
  const tableRef = useRef(null);
  const headRef = useRef(null);
  const actualTableRef = useRef(null);
},
  const rows = ['party', 'website', 'married', 'partner', 'kids', 'religion', 'wealth'];

  const moveLeft = () => {
    //console.log(
    //  headRef.current.clientWidth,
    //  headRef.current.offsetWidth,
    //  headRef.current.scrollLeft,
    //  window.innerWidth,
    //  tableRef.current.clientWidth,
    //  tableRef.current.offsetWidth
    //);
    tableRef.current.scrollLeft -= 400;
    headRef.current.scrollLeft -= 400;
  };
  const moveRight = () => {
    //console.log(
    //  headRef.current.clientWidth,
    //  headRef.current.offsetWidth,
    //  headRef.current.scrollLeft,
    //  window.innerWidth,
    //  tableRef.current.clientWidth,
    //  tableRef.current.offsetWidth
    //);
    if (
      actualTableRef.current.clientWidth >
      headRef.current.clientWidth + headRef.current.scrollLeft
    ) {
      tableRef.current.scrollLeft += 400;
      headRef.current.scrollLeft += 400;
    }
  };
  const classes = useStyles();
  return (
    <>
      <div className={classes.topRow} ref={headRef}>
        <div className={classes.first}>
          Candidate
          {/*buttons anchored to the first heading which is sticky*/}
          <div className={classes.buttonDiv}>
            <div className={classes.buttonLeft} onClick={moveLeft}>
              <ArrowBack className={classes.whiteIcon} />
            </div>
            <div className={classes.buttonRight} onClick={moveRight}>
              <ArrowForward className={classes.whiteIcon} />
            </div>
          </div>
        </div>
        {
          data.data.map((c) => {
            return <div className={classes.rest}>{c.full_name}</div>
          })
        }
      </div>

      <div className={classes.root}>
        <div className={classes.container} ref={tableRef}>
          <Table className={classes.table} ref={actualTableRef}>
            {/*
            <TableHead>
              <TableRow>
                <VaccineCell>
                  <div>
                    <span className="title">Vaccine Names</span>
                  </div>
                </VaccineCell>
                <VaccineCell>
                  <div>
                    <span>Pfizer / BioNTech</span>
                  </div>
                </VaccineCell>
                <VaccineCell>
                  <div className="headerContainer">
                    <span className="title">Moderna</span>
                  </div>
                </VaccineCell>
                <VaccineCell>
                  <div className="headerContainer">
                    <span className="title">Sputnik</span>
                  </div>
                </VaccineCell>
                <VaccineCell>
                  <div className="headerContainer">
                    <span className="title">Oxford / AstraZeneca</span>
                  </div>
                </VaccineCell>
                <VaccineCell>
                  <div className="headerContainer">
                    <span className="title">Johnson & Johnson</span>
                  </div>
                </VaccineCell>
              </TableRow>
            </TableHead>
		  */}
            <TableBody>
              {/* Website */}
              <TableRow>
                <DataCell>
                  Website{" "}
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <a href="https://www.pfizer.com/" target="_blank">
                      Pfizer Website
                    </a>
                    <br />
                    <a href="https://biontech.de/" target="_blank">
                      BioNTech Website
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <a href="https://www.modernatx.com/" target="_blank">
                      Moderna Website
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <a href="https://sputnikvaccine.com/" target="_blank">
                      Sputnik Website
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <a href="https://www.ovg.ox.ac.uk/" target="_blank">
                      Oxford Vaccine Group
                    </a>
                    <br />
                    <a
                      href="https://www.research.ox.ac.uk/Area/coronavirus-research/vaccine"
                      target="_blank"
                    >
                      Oxford Research
                    </a>
                    <br />
                    <a href="https://www.astrazeneca.com/" target="_blank">
                      AstraZeneca Website
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <a href="https://www.jnj.com/" target="_blank">
                      Johnson & Johnson Website
                    </a>
                  </p>
                </DataCell>
              </TableRow>
              {/* COUNTRY OF ORIGIN */}
              <TableRow>
                <DataCell>
                  <p className="question">Country of Origin</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">USA / Germany</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">USA</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">Russia</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">UK</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">USA</p>
                </DataCell>
              </TableRow>

              {/* MEDICINAL NAME */}
              <TableRow>
                <DataCell>
                  <p className="question">Other Names</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">BNT162b2</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">mRNA-1273</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Gam-COVID-Vac
                    <br />
                    Гам-КОВИД-Вак
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    AZD1222
                    <br />
                    Covishield
                    <br />
                    ChAdOx1 nCoV-19
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    JNJ-78436735
                    <br /> Ad26.COV2.S
                  </p>
                </DataCell>
              </TableRow>

              {/* APPROVED COUNTRIES */}
              <TableRow>
                <DataCell>
                  <p className="question">Approved in Countries</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    USA, UK, EU, Canada, Bahrein, Saudi Arabia
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">UK, USA, EU</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Russia, India, UAE, Hungary, Saudi Arabia, Argentina
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">UK</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">Currently in phase 3 trial</p>
                </DataCell>
              </TableRow>

              {/* PLANNED PRODUCTION */}
              <TableRow>
                <DataCell>
                  <p className="question">Planned Production</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">1.3bn doses in 2021.</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">500m - 1bn doses in 2021.</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">1.2bn doses in 2021.</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">3bn doses in 2021.</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">1bn doses in 2021.</p>
                </DataCell>
              </TableRow>

              {/* VACCINE TYPE */}
              <TableRow>
                <DataCell>
                  <p className="question">Vaccine Type</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">mRNA</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">mRNA</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">Adenovirus in two doses</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Adenovirus in two doses. Still unclear whether it'll be two
                    full doses a month apart or a half dose followed by a full
                    dose a month later
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Adenovirus in one dose, though they're testing two-dose
                  </p>
                </DataCell>
              </TableRow>

              {/* EFFICIENCY */}
              <TableRow>
                <DataCell>
                  <p className="question">Efficacy</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">95%</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">94.5%</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">91.4%</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">90%</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Preliminary results from the Phase 3 trial are expected in
                    January
                  </p>
                </DataCell>
              </TableRow>

              {/* STORAGE TEMPERATURE */}
              <TableRow>
                <DataCell>
                  <p className="question">Storage Temperature</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">-70°C (-94°F)</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">-20°C (-4°F)</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    2-8°C (35.6-46.4°F)
                    <br />
                    In liquid form it must be frozen at -20°C (-4°F). It can be
                    stored up to 6 months at those temperatures
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">2-8°C (35.6-46.4°F)</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Can last 3 months if stored 2-8°C( 35.6-46.4°F)
                    <br />
                    Can last 2 years if stored at -20°C (-4°F)
                  </p>
                </DataCell>
              </TableRow>

              {/* PRICE */}
              <TableRow>
                <DataCell>
                  <p className="question">Price</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">$20</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">$38</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">$20</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">$4</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">$10</p>
                </DataCell>
              </TableRow>

              {/* Doses */}
              <TableRow>
                <DataCell>
                  <p className="question">Doses</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Two 30-microgram doses.
                    <br />
                    Second one is administered between 3 and 12 weeks after the
                    initial one
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Two 100-microgram doses.
                    <br />
                    Second one is administered 4 weeks after the initial one
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Two doses.
                    <br />
                    Second one is administered 3 weeks after the initial one
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    Two doses.
                    <br />
                    Second one is administered between 4 and 12 weeks after the
                    initial one
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">Single dose</p>
                </DataCell>
              </TableRow>

              {/* AGE REQUIREMENT */}
              <TableRow>
                <DataCell>
                  <p className="question">Age requirement</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">16</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">18</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">18</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">16</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">18</p>
                </DataCell>
              </TableRow>

              {/* Trail data*/}
              <TableRow>
                <DataCell colSpan="5">
                  <div className={classes.stickyRow}>TRIAL DATA</div>
                </DataCell>
              </TableRow>

              {/* SIDE EFFECTS */}
              <TableRow className={classes.alignTop}>
                <DataCell>
                  <p className="question">Side Effects</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    43,448 participants with the <b>age of 16 to 55</b> received
                    injections: <b>21,720 with BNT162b2</b> and 21,728 with
                    placebo <br />
                    <br />
                    Fatigue in 59%
                    <br />
                    Headache in 52%
                    <br />
                    Fever(temperature, ≥38°C) in 16%
                    <br />
                    Fever(temperature, ≥38.9° to 40°C) 0.2% after the first
                    dose, 0.8% after the second dose
                    <br />
                    Fever(temperature, ≥40°C) in 2 participants out of 21,720
                    (around 0,000092%)
                    <br />
                    Severe fatigue in 4%
                    <br />
                    Lymphadenopathy in 0.6%
                    <br />
                    <br />
                    More than 55 years of age
                    <br />
                    <br />
                    Fatigue in 51%
                    <br />
                    Headache in 39%
                    <br />
                    Fever(temperature, ≥38°C) in 11%
                    <br />
                    <br />
                    <a
                      href="https://www.nejm.org/doi/full/10.1056/NEJMoa2034577"
                      target="_blank"
                    >
                      Source
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <b>45 adults</b> with the <b>age of 18 to 55</b> separated
                    into 3 groups of 15 receiving 25μg, 100μg or
                    250μg(micrograms)
                    <br />
                    <br />
                    Percentage of subjects experiencing solicited adverse events
                    by symptom, maximum severity, vaccination number, and dose
                    group:
                    <br />
                    <br />
                    After receiving the 1st vaccine
                    <br />
                    <Table>
                      <TableBody>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Symtpom/Dose Group</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">25μg</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">100μg</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">250μg</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Muscle pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 6.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 6.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 26.7%</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Headache</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 20%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 26.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 26.7%
                              <br />
                              Moderate 20%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Joint Pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 6.7%
                              <br />
                              Moderate 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 6.7%</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Fatigue</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 13.3%
                              <br />
                              Moderate 13.3%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 20%
                              <br />
                              Moderate 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 20%
                              <br />
                              Moderate 13.3%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Chills</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 6.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 13.3%</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Nausea</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Moderate 6.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 6.7%</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Size of redness</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Moderate 6.7%
                              <br />
                              Severe 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Severe 6.7%</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Size of swelling</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 13.3%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 6.7%
                              <br />
                              Moderate 6.7%
                              <br />
                              Severe 6.7%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 66.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 80%
                              <br />
                              Moderate 13.3%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 60%
                              <br />
                              Moderate 40%
                            </p>
                          </DataCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                    <br />
                    After receiving the 2nd vaccine
                    <br />
                    <Table>
                      <TableBody>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Symtpom/Dose Group</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">25μg</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">100μg</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">250μg</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Muscle pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 15.4%
                              <br />
                              Moderate 7.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 13.3%
                              <br />
                              Moderate 40%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 35.7%
                              <br />
                              Moderate 50%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Headache</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 15.4%
                              <br />
                              Moderate 7.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 33.3%
                              <br />
                              Moderate 26.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 64.3%
                              <br />
                              Moderate 28.6%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Joint Pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 15.4%
                              <br />
                              Moderate 7.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 13.3%
                              <br />
                              Moderate 40%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 35.7%
                              <br />
                              Moderate 50%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Fatigue</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 30.8%
                              <br />
                              Moderate 7.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 40%
                              <br />
                              Moderate 40%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 14.3%
                              <br />
                              Moderate 42.9%
                              <br />
                              Severe 14.3%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Fever</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 33.3%
                              <br />
                              Moderate 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 35.7%
                              <br />
                              Moderate 14.3%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Chills</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Mild 7.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 53.3%
                              <br />
                              Moderate 26.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 28.6%
                              <br />
                              Moderate 35.7%
                              <br />
                              Severe 21.4%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Nausea</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 40%
                              <br />
                              Moderate 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 7.1%
                              <br />
                              Moderate 14.3%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Size of redness</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 6.7%
                              <br />
                              Severe 6.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Moderate 14.3%
                              <br />
                              Severe 7.1%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Size of swelling</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">Moderate 6.7%</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 7.1%
                              <br />
                              Moderate 14.3%
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Pain</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 69.2%
                              <br />
                              Moderate 7.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 73.3%
                              <br />
                              Moderate 26.7%
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              Mild 71.4%
                              <br />
                              Moderate 28.6%
                            </p>
                          </DataCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                    <a
                      href="https://www.nejm.org/doi/suppl/10.1056/NEJMoa2022483/suppl_file/nejmoa2022483_appendix.pdf"
                      target="_blank"
                    >
                      Source
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">
                    <b>76 healthy adult volunteers aged 18–60 years</b>, with no
                    placebo group.
                    <br />
                    <br />
                    The vaccine comprises two vector components,{" "}
                    <b>
                      recombinant adenovirus type 26 (rAd26) and recombinant
                      adenovirus type 5 (rAd5)
                    </b>
                    , both of which carry the gene for SARS-CoV-2 full-length
                    glycoprotein S <b>(rAd26-S and rAd5-S).</b>
                    <br />
                    <br />
                    Two vaccine forumlations were assesed -{" "}
                    <b>frozen and lyophilised.</b>
                    <br />
                    <br />
                    Gam-COVID-Vac
                    <br />
                    9 volunteers received only rAd26-S.
                    <br />
                    9 volunteers received only rAd5-S.
                    <br />
                    20 volunteers received rAd26-S on day 0 and rAd5-S on day
                    21.
                    <br />
                    <br />
                    Gam-COVID-Vac-Lyo
                    <br />
                    9 volunteers received only rAd26-S.
                    <br />
                    9 volunteers received only rAd5-S.
                    <br />
                    20 volunteers received rAd26-S on day 0 and rAd5-S on day
                    21.
                    <br />
                    <br />
                    Gam-COVID-Vac Side effects
                    <Table>
                      <TableBody>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Symtpom/Group</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">rAd26-S</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">rAd5-S</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              rAd26-S plus rAd5-S
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell colSpan={4}>
                            <p className="answer-default">
                              <b>Systemic Reactions</b>
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hyperthermia</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild(37.0–38.4°C)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">8(89%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(22%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">19(95%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Moderate(38.5–38.9°C)
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Headache</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild(grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">6(67%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">9(45%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(10%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Asthenia(Fatigue)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">11(55%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Muscle and joint pain
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%) </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(22%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">4(20%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Heartbeat(subjective palpitation)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Diarrhea</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(15%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Rhinorrhoea(Runny nose)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default"></p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default"></p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">4(20%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Loss of appetite</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(22%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Pain in the oropharynx(pharyngalgia)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Malaise(Weakness)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(10%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Sore throat</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(10%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hives</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Nasal congestion</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Cough</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Sneezing</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Changes in laboratory variables
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">9(100%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">8(89%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">20(100%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell colSpan={4}>
                            <p className="answer-default">
                              <b>Local Reactions</b>
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Pain</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">7(78%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">5(56%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">8(40%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Oedema(Fluid retention)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hyperthermia</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(10%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Itch</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Swelling</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                    <br />
                    Gam-COVID-Vac-Lyo Side effects
                    <Table>
                      <TableBody>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Symtpom/Group</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">rAd26-S(n=9)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">rAd5-S(n=9)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">
                              rAd26-S plus rAd5-S(n=20)
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell colSpan={4}>
                            <p className="answer-default">
                              <b>Systemic Reactions</b>
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hyperthermia</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild(37.0–38.4°C)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">6(30%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Moderate(38.5–38.9°C)
                            </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(5%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Headache</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild(grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">3(33%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">4(44%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">5(25%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Asthenia(Fatigue)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">4(20%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Muscle and joint pain
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%) </p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(22%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">4(20%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(10%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Heartbeat(subjective palpitation)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Diarrhea</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Rhinorrhoea(Runny nose)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Loss of appetite</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Pain in the oropharynx(pharyngalgia)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Malaise(Weakness)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Sore throat</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hives</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Nasal congestion</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Cough</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Sneezing</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Changes in laboratory variables
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">7(78%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">6(67%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">18(90%)</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Moderate (grade 2)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell colSpan={4}>
                            <p className="answer-default">
                              <b>Local Reactions</b>
                            </p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Pain</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">5(56%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">7(78%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">12(60%)</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">
                              Oedema(Fluid retention)
                            </p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">2(22%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Hyperthermia</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">1(11%)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Itch</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>

                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Swelling</p>
                          </DataCell>
                        </TableRow>
                        <TableRow>
                          <DataCell>
                            <p className="answer-default">Mild (grade 1)</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                          <DataCell>
                            <p className="answer-default">-</p>
                          </DataCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                    <a
                      href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7471804/"
                      target="_blank"
                    >
                      Source
                    </a>
                  </p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">Oxford side effects</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">J&J side effects</p>
                </DataCell>
              </TableRow>

              {/* Pregnancy */}
              <TableRow>
                <DataCell>
                  <p className="question">Tested on pregnant subjects</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">No</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">No</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">No</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">No</p>
                </DataCell>
                <DataCell>
                  <p className="answer-default">No</p>
                </DataCell>
              </TableRow>

            </TableBody>
          </Table>
        </div>
      </div>
    </>
  );
};
export default DataTable;
