import React from "react";
import Header from "./components/Header";
import DataTable from "./components/DataTable.js";
import CssBaseline from "@material-ui/core/CssBaseline";

function App() {
  return (
    <div className="App">
      <CssBaseline />
      <Header />
      <DataTable />
    </div>
  );
}

export default App;
