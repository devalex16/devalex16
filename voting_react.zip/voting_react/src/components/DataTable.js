import React, { useRef } from "react";
import '../App.css';
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { ArrowForward, ArrowBack, Image } from "@material-ui/icons";
import data from '../Assets/data.json';
import { SocialIcon } from 'react-social-icons';

const firstColumnBorderColor = "#20379d";

const useStyles = makeStyles((theme) => {
  
  const tableBorderRadius = '10px';
  const firstColumnColor = "#0C2664";
  const topRowColor = "#d02f41";
  const buttonLeftRightBackground = "#2b39a4";

  const mainFontFamily = "Poppins";

  // const firstColumnColor = "#4659e5";
  // const topRowColor = "#DBE0FF";
  // const darkBlue = "#2b39a4";
  // const mainFontFamily = "Poppins";

  return {
    root: {
      //margin: "0px 40px 40px 40px",
      margin: "0px auto",
      width: "94vw",
      position: "relative",
    },
    container: {
      //height: "70vh",
      //overflowY: "scroll",
      overflowX: "hidden",
      //position: "relative",
      borderLeft: "solid 1px #eaeaea",
      borderRight: "solid 1px #eaeaea",
      borderBottom: "solid 1px #eaeaea",
      borderTop: "none",
      scrollBehavior: "smooth",
    },
    table: {
      borderCollapse: "separate",
      "&>thead>tr>th:first-child  ": {
        backgroundColor: firstColumnColor,
        position: "sticky",
        left: 0,
        top: 0,
        zIndex: 15,
        color: "white",
        fontFamily: mainFontFamily,
        fontWeight: "600",
        textAlign: "center",
        width: "250px",
        maxWidth: "250px",
        minWidth: "250px",
        borderLeft: "none !important",
        padding: "16px",
      },
      "&>tbody>tr>td:first-child": {
        backgroundColor: firstColumnColor,
        borderBottom: "solid 1px " + firstColumnBorderColor,
        position: "sticky",
        left: 0,
        color: "white",
        fontFamily: mainFontFamily,
        fontWeight: "600",
        textAlign: "center",
        width: "282px",
        maxWidth: "282px",
        minWidth: "282px",
        //padding: "16px",
      },
      "&>thead>tr>th": {
        backgroundColor: topRowColor,
        color: "white",
        fontWeight: "600",
        position: "sticky",
        top: 0,
        minWidth: "300px",
        fontFamily: mainFontFamily,
        height: "87px",
        borderTop: "none",
        borderLeft: "none",
        borderRight: "solid 1px #eaeaea",
        zIndex: 10,
        //padding: "16px",
      },
      "&>tbody>tr>td": {
        borderTop: "none",
        borderLeft: "none",
        borderBottom: "solid 1px #808080",
        width: "432px",
        maxWidth: "432px",
        minWidth: "432px",
        //padding: "16px",
      },
      "&>tbody>tr:nth-child(2n)": {
        backgroundColor: "#f5f5f5",
      },
      "& a": {
        textDecoration: "none",
        color: firstColumnColor,
        fontFamily: mainFontFamily,
        fontWeight: "600",
      },
    },
    buttonDiv: {
      position: "absolute",
      zIndex: 100,
      //width: "calc(100vw - 80px)",
      width: "94vw",
      top: "0px",
      left: "0px",
    },
    buttonLeft: {
      position: "absolute",
      left: "232px",
      width: "50px",
      top: "0px",
      height: "86px",
      // backgroundColor: buttonLeftRightBackground,
      fontFamily: mainFontFamily,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    buttonRight: {
      position: "absolute",
      right: "0px",
      width: "50px",
      top: "0px",
      height: "86px",
      // backgroundColor: buttonLeftRightBackground,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    },
    stickyRow: {
      height: "55px",
      width: "300px",
      position: "sticky", //paddingLeft: "500px",

      left: "calc(50vw - 150px)",
      fontSize: "36px",
      color: "white",
      zIndex: 5,
      textAlign: "left",
    },
    whiteIcon: {
      color: theme.palette.common.white,
    },
    alignTop: {
      verticalAlign: "top !important",
    },
    topRow: {
      position: "sticky",
      top: 0,
      left: 0,
      display: "flex",
      //width: "100%",
      //height: "55px",
      margin: "0px auto",
      width: "94vw",
      overflowX: "hidden",
      borderLeft: "solid 0px #eaeaea",
      borderRight: "solid 1px #eaeaea",
      borderRadius: `${tableBorderRadius} ${tableBorderRadius} 0 0`,
      borderTop: "solid 0px #eaeaea",
      borderBottom: "none",
      marginTop: "40px",
      zIndex: "200",
      scrollBehavior: "smooth",
    },
    first: {
      width: "282px",
      minWidth: "282px",
      maxWidth: "282px",
      backgroundColor: firstColumnColor,
      padding: "16px",
      height: "87px",
      display: "flex",
      alignItems: "center",
      borderRadius: `${tableBorderRadius} 0 0 0`,
      justifyContent: "center",
      fontSize: "16px",
      fontWeight: "600",
      fontFamily: mainFontFamily,
      borderRight: "solid 1px #eaeaea",
      borderBottom: "solid 1px " + firstColumnBorderColor,
      // borderLeft: "0px",
      // borderTop: "0px",
      color: "white",
      position: "sticky",
      top: "0px",
      left: "0px",
    },
    rest: {
      width: "432px",
      minWidth: "432px",
      maxWidth: "432px",
      color: 'white',
      backgroundColor: topRowColor,
      fontFamily: mainFontFamily,
      
      padding: "16px",
      height: "87px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "19px",
      fontWeight: "600",
      borderRight: "solid 1px #9a9a9a",
      borderBottom: "solid 1px #9a9a9a"
    },
  };
});
const DataCell = withStyles((theme) => ({
  head: {
    backgroundColor: '#1486e3',
    width: "400px",
    color: theme.palette.common.white,
    borderRight: "solid 1px #e2e2e2",
    borderBottom: "solid 1px #e2e2e2",
    textAlign: "center",
    fontSize: "16px",
  },
  body: {

    fontSize: 14,
    border: "solid 1px #e2e2e2",
    textAlign: "center",
    borderRight: "solid 1px #e2e2e2",
    borderBottom: "solid 1px #e2e2e2",
    padding: 4,
    
    "& p": {
      margin: "6px 0",
    },
  },
}))(TableCell);

const DataTable = () => {
  const tableRef = useRef(null);
  const headRef = useRef(null);
  const actualTableRef = useRef(null);
  const scrollValue = 800;
  const moveLeft = () => {
    //console.log(
    //  headRef.current.clientWidth,
    //  headRef.current.offsetWidth,
    //  headRef.current.scrollLeft,
    //  window.innerWidth,
    //  tableRef.current.clientWidth,
    //  tableRef.current.offsetWidth
    //);
    tableRef.current.scrollLeft -= scrollValue;
    headRef.current.scrollLeft -= scrollValue;
  };
  const moveRight = () => {
    //console.log(
    //  headRef.current.clientWidth,
    //  headRef.current.offsetWidth,
    //  headRef.current.scrollLeft,
    //  window.innerWidth,
    //  tableRef.current.clientWidth,
    //  tableRef.current.offsetWidth
    //);
    if (
      actualTableRef.current.clientWidth >
      headRef.current.clientWidth + headRef.current.scrollLeft
    ) {
      tableRef.current.scrollLeft += scrollValue;
      headRef.current.scrollLeft += scrollValue;
    }
  };
  const rows = [['photo', "Photo"], ['website', "Website"], ['social', "Social"], ['married', "Marriage Status"], ['partner', "Partner"], ['kids', 'Kids'], ['religion', 'Religion'], ['wealth', 'Wealth'], ['!party', 'Subtitle'], ['party', 'Party'], ['party_website', 'Website'], ['party_social', "Social"],
  ['photo', "Photo"], ['website', "Website"], ['social', "Social"], ['married', "Marriage Status"], ['partner', "Partner"], ['kids', 'Kids'], ['religion', 'Religion'], ['wealth', 'Wealth'], ['!party', 'Subtitle'], ['party', 'Party'], ['party_website', 'Website'], ['party_social', "Social"],
  ['photo', "Photo"], ['website', "Website"], ['social', "Social"], ['married', "Marriage Status"], ['partner', "Partner"], ['kids', 'Kids'], ['religion', 'Religion'], ['wealth', 'Wealth'], ['!party', 'Subtitle'], ['party', 'Party'], ['party_website', 'Website'], ['party_social', "Social"],
  ['photo', "Photo"], ['website', "Website"], ['social', "Social"], ['married', "Marriage Status"], ['partner', "Partner"], ['kids', 'Kids'], ['religion', 'Religion'], ['wealth', 'Wealth'], ['!party', 'Subtitle'], ['party', 'Party'], ['party_website', 'Website'], ['party_social', "Social"],
  ['photo', "Photo"], ['website', "Website"], ['social', "Social"], ['married', "Marriage Status"], ['partner', "Partner"], ['kids', 'Kids'], ['religion', 'Religion'], ['wealth', 'Wealth'], ['!party', 'Subtitle'], ['party', 'Party'], ['party_website', 'Website'], ['party_social', "Social"]
];
  // const headers = [, "Website", "Social", "Political Party", "Married", "Marriage Partner", "Kids", "Religion", "Wealth"]
  const classes = useStyles();

  function contentParty(candidate) {
    if (!candidate.party) {
      return <></>
    }
    let p = candidate.party.toLowerCase().trim()
    let isDemocratic = (p == "democratic")
    let isRepublican = (p == "republican")

    return <div >
      {isDemocratic ? <img src={process.env.REACT_APP_BASE_URL + `/icon_democratic.png`} className='imageParty' /> : <></>}
      {isRepublican ? <img src={process.env.REACT_APP_BASE_URL + `/icon_republican.png`} className='imageParty' /> : <></>}
      <span className="field_name textBold">{candidate.party}</span>
    </div>
  }

  function contentPartySocialIcons(candidate) {
    return <>
      {socialIcons([candidate.party_twitter_link, candidate.party_fb_link, candidate.party_instagram_link])}
    </>
  }

  function contentSocialIcons(candidate) {
    return <>
      {socialIcons([candidate.twitter_link, candidate.fb_link, candidate.instagram_link])}
    </>
  }

  function socialIcons(links) {
    return links.map((link) => {
      return socialIcon(link)
    })
  }

  function socialIcon(link) {
    if(link.includes('twitter') || link.includes('facebook') || link.includes('instagram')) {
      return <SocialIcon className="socialIcon" target="_blank" url={link} />
    } else {
      return <></>
    }
  }

  function link(href, title) {
    let text = title ?? href
    if(isURL(href)) {
      return <a target="_blank" href={href}>{text}</a>
    } else {
      return <span>{text}</span>
    }
  }

  function contentPhoto(photoName) {
    return <>
      <img className='candidate-img' src={process.env.REACT_APP_BASE_URL + `/${photoName}`} />
    </>
  }

  function isURL(link) {
    let regex = /^(https?:\/\/)?((([a-z\d]([a-z\d-]*[a-z\d])*)\.)+[a-z]{2,}|((\d{1,3}\.){3}\d{1,3}))(\:\d+)?(\/[-a-z\d%_.~+]*)*(\?[;&a-z\d%_.~+=-]*)?(\#[-a-z\d_]*)?$/i
    return regex.test(link)
  }

  return (
    <>
    
      <div className={classes.topRow} ref={headRef}>
        <div className={classes.first}>
          Candidate
          {/*buttons anchored to the first heading which is sticky*/}
          <div className={classes.buttonDiv}>
            <div className={classes.buttonLeft} onClick={moveLeft}>
              <ArrowBack className={classes.whiteIcon} />
            </div>
            <div className={classes.buttonRight} onClick={moveRight}>
              <ArrowForward className={classes.whiteIcon} />
            </div>
          </div>
        </div>
        {
          data.data.map((c) => {
            return <div className={classes.rest}>{c.full_name}</div>
          })
        }
      </div>

      <div className={classes.root}>
        <div className={classes.container} ref={tableRef}>
          <Table className={classes.table} ref={actualTableRef}>

            <TableBody>
              {
                rows.map((header, i) => {
                  return <TableRow>
                    {
                      !rows[i][0].startsWith('!') &&
                      <DataCell className="dc-field-name">
                        <p className="field_name">{header[1]}</p>
                      </DataCell>
                    }

                    {
                      rows[i][0].startsWith('!') &&
                      <DataCell colSpan="6">
                        <div className={classes.stickyRow}>{rows[i][1]}</div>
                      </DataCell>
                    }

                    {
                      data.data.map((c) => {
                        if (rows[i][0].startsWith('!')) {
                          return <></>
                        } else if (rows[i][0] === 'photo') {
                          return <DataCell className='dc-photo'>
                            {contentPhoto(`candidates/${c.photo}`)}
                          </DataCell>
                        } else if (rows[i][0] === "social") {
                          return <DataCell className='dc-data'>
                            {contentSocialIcons(c)}
                          </DataCell>
                        } else if (rows[i][0] === "website" || rows[i][0] === "party_website") {
                          return <DataCell className='dc-data'>
                            { link(c[rows[i][0]])}
                          </DataCell>
                        } else if (rows[i][0] === "party") {
                          return <DataCell className='dc-data'>
                            {contentParty(c)}
                          </DataCell>
                        } else if (rows[i][0] === "party_social") {
                          return <DataCell className='dc-data'>
                            {contentPartySocialIcons(c)}
                          </DataCell>
                        } else {
                          return <DataCell className='dc-data'>
                            <p className="field_name">{c[rows[i][0]]}</p>
                          </DataCell>
                        }
                      })
                    }

                  </TableRow>
                })
              }
            </TableBody>
          </Table>
        </div>
      </div>
    </>
  );
};
export default DataTable;
